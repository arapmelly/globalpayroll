-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: burusacco
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `x_accounts`
--

DROP TABLE IF EXISTS `x_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_accounts`
--

LOCK TABLES `x_accounts` WRITE;
/*!40000 ALTER TABLE `x_accounts` DISABLE KEYS */;
INSERT INTO `x_accounts` VALUES (1,'ASSET',1010,'cash',1,'2016-08-29 07:09:06','2016-08-29 07:09:06'),(2,'ASSET',1020,'loan portfolio',1,'2016-08-29 07:09:24','2016-08-29 07:09:24'),(3,'INCOME',2010,'loan fees',1,'2016-08-29 07:09:40','2016-08-29 07:09:40'),(4,'INCOME',2020,'loan interest',1,'2016-08-29 07:09:55','2016-08-29 07:09:55'),(5,'INCOME',2030,'loan penalties',1,'2016-08-29 07:18:16','2016-08-29 07:18:16'),(6,'LIABILITY',5010,'loan overpayment',1,'2016-08-29 07:18:44','2016-08-29 07:18:44'),(7,'EXPENSE',3010,'loans written off',1,'2016-08-29 07:20:42','2016-08-29 07:20:42');
/*!40000 ALTER TABLE `x_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_assigned_roles`
--

DROP TABLE IF EXISTS `x_assigned_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_assigned_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assigned_roles_user_id_foreign` (`user_id`),
  KEY `assigned_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `assigned_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `x_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `assigned_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `x_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_assigned_roles`
--

LOCK TABLES `x_assigned_roles` WRITE;
/*!40000 ALTER TABLE `x_assigned_roles` DISABLE KEYS */;
INSERT INTO `x_assigned_roles` VALUES (1,2,1);
/*!40000 ALTER TABLE `x_assigned_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_assignvehicles`
--

DROP TABLE IF EXISTS `x_assignvehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_assignvehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `vehicleincomes_vehicle_id_index` (`vehicle_id`),
  KEY `vehicleincomes_member_id_index` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_assignvehicles`
--

LOCK TABLES `x_assignvehicles` WRITE;
/*!40000 ALTER TABLE `x_assignvehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_assignvehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_audits`
--

DROP TABLE IF EXISTS `x_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_audits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` float(10,0) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_audits`
--

LOCK TABLES `x_audits` WRITE;
/*!40000 ALTER TABLE `x_audits` DISABLE KEYS */;
INSERT INTO `x_audits` VALUES (1,'2016-08-29','developer','member creation','Member',0,'2016-08-29 07:07:04','2016-08-29 07:07:04'),(2,'2016-08-29','developer','loan product creation','Loans',0,'2016-08-29 07:35:20','2016-08-29 07:35:20'),(3,'2016-08-29','developer','loan disbursement','Loans',53250,'2016-08-29 07:36:47','2016-08-29 07:36:47'),(4,'2016-08-29','developer','loan application','Loans',50000,'2016-08-29 07:41:52','2016-08-29 07:41:52'),(5,'2016-08-29','developer','loan disbursement','Loans',53250,'2016-08-29 07:42:22','2016-08-29 07:42:22'),(6,'2016-08-29','developer','loan repayment','Loans',8833,'2016-08-29 08:02:36','2016-08-29 08:02:36');
/*!40000 ALTER TABLE `x_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_autoprocesses`
--

DROP TABLE IF EXISTS `x_autoprocesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_autoprocesses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_autoprocesses`
--

LOCK TABLES `x_autoprocesses` WRITE;
/*!40000 ALTER TABLE `x_autoprocesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_autoprocesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_bank_branches`
--

DROP TABLE IF EXISTS `x_bank_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_bank_branches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_code` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_branch_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bank_id` int(10) unsigned NOT NULL,
  `organization_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `bank_branches_bank_id_foreign` (`bank_id`),
  KEY `bank_branches_organization_id_foreign` (`organization_id`),
  CONSTRAINT `bank_branches_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `x_organizations` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `bank_branches_bank_id_foreign` FOREIGN KEY (`bank_id`) REFERENCES `x_banks` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_bank_branches`
--

LOCK TABLES `x_bank_branches` WRITE;
/*!40000 ALTER TABLE `x_bank_branches` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_bank_branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_banks`
--

DROP TABLE IF EXISTS `x_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_banks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bank_code` int(11) NOT NULL DEFAULT '0',
  `organization_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `banks_organization_id_foreign` (`organization_id`),
  CONSTRAINT `banks_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `x_organizations` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_banks`
--

LOCK TABLES `x_banks` WRITE;
/*!40000 ALTER TABLE `x_banks` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_branches`
--

DROP TABLE IF EXISTS `x_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_branches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_branches`
--

LOCK TABLES `x_branches` WRITE;
/*!40000 ALTER TABLE `x_branches` DISABLE KEYS */;
INSERT INTO `x_branches` VALUES (1,'Head Office','2016-08-29 07:03:51','2016-08-29 07:03:51');
/*!40000 ALTER TABLE `x_branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_categories`
--

DROP TABLE IF EXISTS `x_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_categories`
--

LOCK TABLES `x_categories` WRITE;
/*!40000 ALTER TABLE `x_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_charge_loanproduct`
--

DROP TABLE IF EXISTS `x_charge_loanproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_charge_loanproduct` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charge_id` int(10) unsigned NOT NULL,
  `loanproduct_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loancharges_charge_id_foreign` (`charge_id`),
  KEY `loancharges_loanproduct_id_foreign` (`loanproduct_id`),
  CONSTRAINT `loancharges_loanproduct_id_foreign` FOREIGN KEY (`loanproduct_id`) REFERENCES `x_loanproducts` (`id`),
  CONSTRAINT `loancharges_charge_id_foreign` FOREIGN KEY (`charge_id`) REFERENCES `x_charges` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_charge_loanproduct`
--

LOCK TABLES `x_charge_loanproduct` WRITE;
/*!40000 ALTER TABLE `x_charge_loanproduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_charge_loanproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_charge_savingproduct`
--

DROP TABLE IF EXISTS `x_charge_savingproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_charge_savingproduct` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charge_id` int(10) unsigned NOT NULL,
  `savingproduct_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `savingcharges_charge_id_foreign` (`charge_id`),
  KEY `savingcharges_savingproduct_id_foreign` (`savingproduct_id`),
  CONSTRAINT `savingcharges_savingproduct_id_foreign` FOREIGN KEY (`savingproduct_id`) REFERENCES `x_savingproducts` (`id`),
  CONSTRAINT `savingcharges_charge_id_foreign` FOREIGN KEY (`charge_id`) REFERENCES `x_charges` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_charge_savingproduct`
--

LOCK TABLES `x_charge_savingproduct` WRITE;
/*!40000 ALTER TABLE `x_charge_savingproduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_charge_savingproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_charges`
--

DROP TABLE IF EXISTS `x_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_charges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `calculation_method` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `percentage_of` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` float(10,0) NOT NULL,
  `fee` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `disabled` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_charges`
--

LOCK TABLES `x_charges` WRITE;
/*!40000 ALTER TABLE `x_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_currencies`
--

DROP TABLE IF EXISTS `x_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_currencies`
--

LOCK TABLES `x_currencies` WRITE;
/*!40000 ALTER TABLE `x_currencies` DISABLE KEYS */;
INSERT INTO `x_currencies` VALUES (1,'Kenyan Shillings','KES','2016-08-29 07:03:51','2016-08-29 07:03:51');
/*!40000 ALTER TABLE `x_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_documents`
--

DROP TABLE IF EXISTS `x_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `documents_member_id_foreign` (`member_id`),
  CONSTRAINT `documents_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_documents`
--

LOCK TABLES `x_documents` WRITE;
/*!40000 ALTER TABLE `x_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_groups`
--

DROP TABLE IF EXISTS `x_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_groups`
--

LOCK TABLES `x_groups` WRITE;
/*!40000 ALTER TABLE `x_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_journals`
--

DROP TABLE IF EXISTS `x_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_journals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `trans_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `amount` float(10,0) NOT NULL,
  `initiated_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `void` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `journals_account_id_foreign` (`account_id`),
  CONSTRAINT `journals_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `x_accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_journals`
--

LOCK TABLES `x_journals` WRITE;
/*!40000 ALTER TABLE `x_journals` DISABLE KEYS */;
INSERT INTO `x_journals` VALUES (1,'2016-08-29','1472465327',1,50000,'system','credit','loan disbursement','2016-08-29 07:36:47','2016-08-29 07:36:47',0),(2,'2016-08-29','1472465327',2,50000,'system','debit','loan disbursement','2016-08-29 07:36:47','2016-08-29 07:36:47',0),(3,'2016-08-29','1472465302',1,50000,'system','credit','loan disbursement','2016-08-29 07:42:22','2016-08-29 07:42:22',0),(4,'2016-08-29','1472465302',2,50000,'system','debit','loan disbursement','2016-08-29 07:42:22','2016-08-29 07:42:22',0),(5,'2016-08-29','1472468915',4,500,'system','credit','interest repayment','2016-08-29 08:02:35','2016-08-29 08:02:35',0),(6,'2016-08-29','1472468915',1,500,'system','debit','interest repayment','2016-08-29 08:02:35','2016-08-29 08:02:35',0);
/*!40000 ALTER TABLE `x_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_kins`
--

DROP TABLE IF EXISTS `x_kins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_kins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `goodwill` float(10,0) DEFAULT NULL,
  `id_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `kins_member_id_foreign` (`member_id`),
  CONSTRAINT `kins_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_kins`
--

LOCK TABLES `x_kins` WRITE;
/*!40000 ALTER TABLE `x_kins` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_kins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loanaccounts`
--

DROP TABLE IF EXISTS `x_loanaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loanaccounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `loanproduct_id` int(10) unsigned NOT NULL,
  `is_new_application` tinyint(1) NOT NULL DEFAULT '1',
  `application_date` date NOT NULL,
  `amount_applied` float(10,0) NOT NULL,
  `interest_rate` float(10,0) NOT NULL,
  `period` int(11) NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `date_approved` date DEFAULT NULL,
  `amount_approved` float(10,0) DEFAULT NULL,
  `is_rejected` tinyint(1) NOT NULL DEFAULT '0',
  `rejection_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_amended` tinyint(1) NOT NULL DEFAULT '0',
  `date_amended` date DEFAULT NULL,
  `is_disbursed` tinyint(1) NOT NULL DEFAULT '0',
  `amount_disbursed` float(10,0) DEFAULT NULL,
  `date_disbursed` date DEFAULT NULL,
  `repayment_start_date` date DEFAULT NULL,
  `is_matured` tinyint(1) NOT NULL DEFAULT '0',
  `is_written_off` tinyint(1) NOT NULL DEFAULT '0',
  `is_defaulted` tinyint(1) NOT NULL DEFAULT '0',
  `is_overpaid` tinyint(1) NOT NULL DEFAULT '0',
  `account_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repayment_duration` int(11) DEFAULT NULL,
  `is_top_up` tinyint(1) DEFAULT '0',
  `top_up_amount` float(15,3) DEFAULT '0.000',
  `loan_purpose` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loanaccounts_member_id_foreign` (`member_id`),
  KEY `loanaccounts_loanproduct_id_foreign` (`loanproduct_id`),
  CONSTRAINT `loanaccounts_loanproduct_id_foreign` FOREIGN KEY (`loanproduct_id`) REFERENCES `x_loanproducts` (`id`),
  CONSTRAINT `loanaccounts_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loanaccounts`
--

LOCK TABLES `x_loanaccounts` WRITE;
/*!40000 ALTER TABLE `x_loanaccounts` DISABLE KEYS */;
INSERT INTO `x_loanaccounts` VALUES (1,1,1,0,'2016-08-29',50000,1,6,1,'2016-08-29',50000,0,NULL,0,NULL,1,50000,'2016-08-29','2016-08-29',0,0,0,0,'MZL-BS.1-2',6,0,0.000,NULL,'2016-08-29 07:36:47','2016-08-29 07:36:47'),(2,1,1,0,'2016-08-29',50000,1,12,1,'2016-08-29',50000,0,NULL,0,NULL,1,50000,'2016-08-29','2016-08-29',0,0,0,0,'MZL-BS.1-3',12,0,0.000,NULL,'2016-08-29 07:41:52','2016-08-29 07:42:22');
/*!40000 ALTER TABLE `x_loanaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loanguarantors`
--

DROP TABLE IF EXISTS `x_loanguarantors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loanguarantors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `loanaccount_id` int(10) unsigned NOT NULL,
  `amount` float(10,0) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loanguarantors_member_id_foreign` (`member_id`),
  KEY `loanguarantors_loanaccount_id_foreign` (`loanaccount_id`),
  CONSTRAINT `loanguarantors_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`),
  CONSTRAINT `loanguarantors_loanaccount_id_foreign` FOREIGN KEY (`loanaccount_id`) REFERENCES `x_loanaccounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loanguarantors`
--

LOCK TABLES `x_loanguarantors` WRITE;
/*!40000 ALTER TABLE `x_loanguarantors` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_loanguarantors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loanpostings`
--

DROP TABLE IF EXISTS `x_loanpostings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loanpostings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loanproduct_id` int(10) unsigned NOT NULL,
  `transaction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `debit_account` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `credit_account` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loanpostings_loanproduct_id_foreign` (`loanproduct_id`),
  CONSTRAINT `loanpostings_loanproduct_id_foreign` FOREIGN KEY (`loanproduct_id`) REFERENCES `x_loanproducts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loanpostings`
--

LOCK TABLES `x_loanpostings` WRITE;
/*!40000 ALTER TABLE `x_loanpostings` DISABLE KEYS */;
INSERT INTO `x_loanpostings` VALUES (1,1,'disbursal','2','1','2016-08-29 07:35:20','2016-08-29 07:35:20'),(2,1,'principal_repayment','1','2','2016-08-29 07:35:20','2016-08-29 07:35:20'),(3,1,'interest_repayment','1','4','2016-08-29 07:35:20','2016-08-29 07:35:20'),(4,1,'loan_write_off','7','2','2016-08-29 07:35:20','2016-08-29 07:35:20'),(5,1,'fee_payment','1','3','2016-08-29 07:35:20','2016-08-29 07:35:20'),(6,1,'penalty_payment','1','5','2016-08-29 07:35:20','2016-08-29 07:35:20'),(7,1,'loan_overpayment','1','6','2016-08-29 07:35:20','2016-08-29 07:35:20'),(8,1,'overpayment_refund','6','1','2016-08-29 07:35:20','2016-08-29 07:35:20');
/*!40000 ALTER TABLE `x_loanpostings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loanproducts`
--

DROP TABLE IF EXISTS `x_loanproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loanproducts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `short_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `formula` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `interest_rate` float(10,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `amortization` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'EI',
  `period` int(11) DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auto_loan_limit` float DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loanproducts`
--

LOCK TABLES `x_loanproducts` WRITE;
/*!40000 ALTER TABLE `x_loanproducts` DISABLE KEYS */;
INSERT INTO `x_loanproducts` VALUES (1,'mazao loan','MZL','RB',1,'2016-08-29 07:35:20','2016-08-29 07:35:20','EI',12,'KES',50000);
/*!40000 ALTER TABLE `x_loanproducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loanrepayments`
--

DROP TABLE IF EXISTS `x_loanrepayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loanrepayments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loanaccount_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `principal_paid` float(12,2) NOT NULL DEFAULT '0.00',
  `interest_paid` float(12,2) NOT NULL DEFAULT '0.00',
  `void` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loanrepayments_loanaccount_id_foreign` (`loanaccount_id`),
  CONSTRAINT `loanrepayments_loanaccount_id_foreign` FOREIGN KEY (`loanaccount_id`) REFERENCES `x_loanaccounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loanrepayments`
--

LOCK TABLES `x_loanrepayments` WRITE;
/*!40000 ALTER TABLE `x_loanrepayments` DISABLE KEYS */;
INSERT INTO `x_loanrepayments` VALUES (1,1,'2016-08-29',0.00,500.00,0,'2016-08-29 08:02:35','2016-08-29 08:02:35'),(2,1,'2016-08-29',8333.33,0.00,0,'2016-08-29 08:02:35','2016-08-29 08:02:35');
/*!40000 ALTER TABLE `x_loanrepayments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_loantransactions`
--

DROP TABLE IF EXISTS `x_loantransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_loantransactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loanaccount_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` float(10,2) NOT NULL DEFAULT '0.00',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_via` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `void` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `loantransactions_loanaccount_id_foreign` (`loanaccount_id`),
  CONSTRAINT `loantransactions_loanaccount_id_foreign` FOREIGN KEY (`loanaccount_id`) REFERENCES `x_loanaccounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_loantransactions`
--

LOCK TABLES `x_loantransactions` WRITE;
/*!40000 ALTER TABLE `x_loantransactions` DISABLE KEYS */;
INSERT INTO `x_loantransactions` VALUES (1,1,'2016-08-29','loan disbursement',NULL,53250.00,'debit',NULL,0,'2016-08-29 07:36:47','2016-08-29 07:36:47'),(2,2,'2016-08-29','loan disbursement',NULL,53250.00,'debit',NULL,0,'2016-08-29 07:42:22','2016-08-29 07:42:22'),(3,1,'2016-08-29','loan repayment',NULL,8833.00,'credit','Cash',0,'2016-08-29 08:02:35','2016-08-29 08:02:35');
/*!40000 ALTER TABLE `x_loantransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_members`
--

DROP TABLE IF EXISTS `x_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `membership_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default_photo.png',
  `signature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_number` bigint(20) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `bank_account_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `bank_id` int(10) unsigned NOT NULL,
  `bank_branch_id` int(10) unsigned NOT NULL,
  `monthly_remittance_amount` float(15,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` tinyint(1) DEFAULT '1',
  `is_css_active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `membership_no` (`membership_no`),
  KEY `members_group_id_foreign` (`group_id`),
  KEY `members_branch_id_foreign` (`branch_id`),
  KEY `members_bank_id_foreign` (`bank_id`),
  KEY `members_bank_branch_id_foreign` (`bank_branch_id`),
  CONSTRAINT `members_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `x_groups` (`id`),
  CONSTRAINT `members_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `x_branches` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_members`
--

LOCK TABLES `x_members` WRITE;
/*!40000 ALTER TABLE `x_members` DISABLE KEYS */;
INSERT INTO `x_members` VALUES (1,'jacob chumo','BS.1','default_photo.png',NULL,'M',28043122,'0716756944','','','',NULL,1,0,0,0.00,'2016-08-29 07:07:04','2016-08-29 09:19:00',1,0);
/*!40000 ALTER TABLE `x_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_migrations`
--

DROP TABLE IF EXISTS `x_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_migrations`
--

LOCK TABLES `x_migrations` WRITE;
/*!40000 ALTER TABLE `x_migrations` DISABLE KEYS */;
INSERT INTO `x_migrations` VALUES ('2013_11_13_192002_create_x_vehicleincomes_table',1),('2014_11_13_192002_create_x_organizations_table',1),('2015_11_13_192000_create_x_banks_table',1),('2015_11_13_192002_create_x_accounts_table',1),('2015_11_13_192002_create_x_assigned_roles_table',1),('2015_11_13_192002_create_x_assignvehicles_table',1),('2015_11_13_192002_create_x_audits_table',1),('2015_11_13_192002_create_x_bank_branches_table',1),('2015_11_13_192002_create_x_branches_table',1),('2015_11_13_192002_create_x_categories_table',1),('2015_11_13_192002_create_x_charge_loanproduct_table',1),('2015_11_13_192002_create_x_charge_savingproduct_table',1),('2015_11_13_192002_create_x_charges_table',1),('2015_11_13_192002_create_x_currencies_table',1),('2015_11_13_192002_create_x_documents_table',1),('2015_11_13_192002_create_x_groups_table',1),('2015_11_13_192002_create_x_journals_table',1),('2015_11_13_192002_create_x_kins_table',1),('2015_11_13_192002_create_x_loanaccounts_table',1),('2015_11_13_192002_create_x_loanguarantors_table',1),('2015_11_13_192002_create_x_loanpostings_table',1),('2015_11_13_192002_create_x_loanproducts_table',1),('2015_11_13_192002_create_x_loanrepayments_table',1),('2015_11_13_192002_create_x_loantransactions_table',1),('2015_11_13_192002_create_x_members_table',1),('2015_11_13_192002_create_x_orders_table',1),('2015_11_13_192002_create_x_password_reminders_table',1),('2015_11_13_192002_create_x_permission_role_table',1),('2015_11_13_192002_create_x_permissions_table',1),('2015_11_13_192002_create_x_products_table',1),('2015_11_13_192002_create_x_roles_table',1),('2015_11_13_192002_create_x_savingaccounts_table',1),('2015_11_13_192002_create_x_savingpostings_table',1),('2015_11_13_192002_create_x_savingproducts_table',1),('2015_11_13_192002_create_x_savingtransactions_table',1),('2015_11_13_192002_create_x_shareaccounts_table',1),('2015_11_13_192002_create_x_shares_table',1),('2015_11_13_192002_create_x_sharetransactions_table',1),('2015_11_13_192002_create_x_user_role_table',1),('2015_11_13_192002_create_x_users_table',1),('2015_11_13_192002_create_x_vehicleexpenses_table',1),('2015_11_13_192002_create_x_vehicles_table',1),('2015_11_13_192002_create_x_vendors_table',1),('2015_11_13_192006_add_foreign_keys_to_x_assigned_roles_table',1),('2015_11_13_192006_add_foreign_keys_to_x_charge_loanproduct_table',1),('2015_11_13_192006_add_foreign_keys_to_x_charge_savingproduct_table',1),('2015_11_13_192006_add_foreign_keys_to_x_documents_table',1),('2015_11_13_192006_add_foreign_keys_to_x_journals_table',1),('2015_11_13_192006_add_foreign_keys_to_x_kins_table',1),('2015_11_13_192006_add_foreign_keys_to_x_loanaccounts_table',1),('2015_11_13_192006_add_foreign_keys_to_x_loanguarantors_table',1),('2015_11_13_192006_add_foreign_keys_to_x_loanpostings_table',1),('2015_11_13_192006_add_foreign_keys_to_x_loanrepayments_table',1),('2015_11_13_192006_add_foreign_keys_to_x_loantransactions_table',1),('2015_11_13_192006_add_foreign_keys_to_x_members_table',1),('2015_11_13_192006_add_foreign_keys_to_x_orders_table',1),('2015_11_13_192006_add_foreign_keys_to_x_permission_role_table',1),('2015_11_13_192006_add_foreign_keys_to_x_products_table',1),('2015_11_13_192006_add_foreign_keys_to_x_savingaccounts_table',1),('2015_11_13_192006_add_foreign_keys_to_x_savingpostings_table',1),('2015_11_13_192006_add_foreign_keys_to_x_savingtransactions_table',1),('2015_11_13_192006_add_foreign_keys_to_x_shareaccounts_table',1),('2015_11_13_192006_add_foreign_keys_to_x_sharetransactions_table',1),('2015_11_13_192006_add_foreign_keys_to_x_user_role_table',1),('2015_11_13_192006_add_foreign_keys_to_x_users_table',1),('2015_11_20_083755_create_autoprocesses_table',1);
/*!40000 ALTER TABLE `x_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_orders`
--

DROP TABLE IF EXISTS `x_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `order_date` date NOT NULL,
  `customer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sacco` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `orders_product_id_index` (`product_id`),
  CONSTRAINT `orders_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `x_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_orders`
--

LOCK TABLES `x_orders` WRITE;
/*!40000 ALTER TABLE `x_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_organizations`
--

DROP TABLE IF EXISTS `x_organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_organizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'XARA CBS',
  `logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `license_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'evaluation',
  `license_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licensed` bigint(20) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_organizations`
--

LOCK TABLES `x_organizations` WRITE;
/*!40000 ALTER TABLE `x_organizations` DISABLE KEYS */;
INSERT INTO `x_organizations` VALUES (1,'Buru Sacco',NULL,NULL,NULL,NULL,NULL,'2016-08-29 07:03:51','2016-08-29 07:05:01','evaluation','1D4ICYC14A',NULL,100);
/*!40000 ALTER TABLE `x_organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_password_reminders`
--

DROP TABLE IF EXISTS `x_password_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_password_reminders`
--

LOCK TABLES `x_password_reminders` WRITE;
/*!40000 ALTER TABLE `x_password_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_password_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_permission_role`
--

DROP TABLE IF EXISTS `x_permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_permission_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `x_roles` (`id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `x_permissions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_permission_role`
--

LOCK TABLES `x_permission_role` WRITE;
/*!40000 ALTER TABLE `x_permission_role` DISABLE KEYS */;
INSERT INTO `x_permission_role` VALUES (1,2,1),(2,5,1),(3,8,1),(4,11,1),(5,16,1),(6,20,1),(7,23,1);
/*!40000 ALTER TABLE `x_permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_permissions`
--

DROP TABLE IF EXISTS `x_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_permissions`
--

LOCK TABLES `x_permissions` WRITE;
/*!40000 ALTER TABLE `x_permissions` DISABLE KEYS */;
INSERT INTO `x_permissions` VALUES (1,'edit_loan_product','edit loan products','Loanproduct','2016-08-29 07:03:51','2016-08-29 07:03:51'),(2,'view_loan_product','view loan products','Loanproduct','2016-08-29 07:03:51','2016-08-29 07:03:51'),(3,'delete_loan_product','delete loan products','Loanproduct','2016-08-29 07:03:51','2016-08-29 07:03:51'),(4,'create_loan_account','create loan account','Loanaccount','2016-08-29 07:03:51','2016-08-29 07:03:51'),(5,'view_loan_account','view loan account','Loanaccount','2016-08-29 07:03:51','2016-08-29 07:03:51'),(6,'approve_loan_account','approve loan','Loanaccount','2016-08-29 07:03:52','2016-08-29 07:03:52'),(7,'create_savingproduct','create  Product','Savingproduct','2016-08-29 07:03:52','2016-08-29 07:03:52'),(8,'view_savingproduct','view  Product','Savingproduct','2016-08-29 07:03:52','2016-08-29 07:03:52'),(9,'delete_savingproduct','Delete Product','Savingproduct','2016-08-29 07:03:52','2016-08-29 07:03:52'),(10,'disburse_loan','disburse loan','Loanaccount','2016-08-29 07:03:52','2016-08-29 07:03:52'),(11,'view_savings_account','view savings account','Savingaccount','2016-08-29 07:03:52','2016-08-29 07:03:52'),(12,'open_saving_account','Open savings account','Savingaccount','2016-08-29 07:03:52','2016-08-29 07:03:52'),(13,'create_member','Create Member','Member','2016-08-29 07:03:52','2016-08-29 07:03:52'),(14,'deactivate_member','Deactivate Member','Member','2016-08-29 07:03:52','2016-08-29 07:03:52'),(15,'update_member','Update Member','Member','2016-08-29 07:03:52','2016-08-29 07:03:52'),(16,'view_users','View users','Users','2016-08-29 07:03:52','2016-08-29 07:03:52'),(17,'create_users','Create users','Users','2016-08-29 07:03:52','2016-08-29 07:03:52'),(18,'deactivate_users','Deactivate users','Users','2016-08-29 07:03:52','2016-08-29 07:03:52'),(19,'create_roles','Create roles','Roles','2016-08-29 07:03:52','2016-08-29 07:03:52'),(20,'view_roles','View roles','Roles','2016-08-29 07:03:52','2016-08-29 07:03:52'),(21,'deactivate_roles','Deactivate roles','Roles','2016-08-29 07:03:52','2016-08-29 07:03:52'),(22,'create_accounts','Create Accounts','Accounting','2016-08-29 07:03:52','2016-08-29 07:03:52'),(23,'view_accounts','View Accounts','Accounting','2016-08-29 07:03:52','2016-08-29 07:03:52'),(24,'deactivate_accounts','Deactivate Accounts','Accounting','2016-08-29 07:03:52','2016-08-29 07:03:52'),(25,'create_journal','Create Journal Entry','Accounting','2016-08-29 07:03:52','2016-08-29 07:03:52');
/*!40000 ALTER TABLE `x_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_products`
--

DROP TABLE IF EXISTS `x_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,0) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_vendor_id_index` (`vendor_id`),
  CONSTRAINT `products_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `x_vendors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_products`
--

LOCK TABLES `x_products` WRITE;
/*!40000 ALTER TABLE `x_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_roles`
--

DROP TABLE IF EXISTS `x_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_roles`
--

LOCK TABLES `x_roles` WRITE;
/*!40000 ALTER TABLE `x_roles` DISABLE KEYS */;
INSERT INTO `x_roles` VALUES (1,'official','2016-08-29 08:43:16','2016-08-29 08:43:16');
/*!40000 ALTER TABLE `x_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_savingaccounts`
--

DROP TABLE IF EXISTS `x_savingaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_savingaccounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `savingproduct_id` int(10) unsigned NOT NULL,
  `account_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `savingaccounts_member_id_foreign` (`member_id`),
  KEY `x_savingaccounts_fk` (`savingproduct_id`),
  CONSTRAINT `savingaccounts_fk` FOREIGN KEY (`savingproduct_id`) REFERENCES `x_savingproducts` (`id`),
  CONSTRAINT `savingaccounts_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_savingaccounts`
--

LOCK TABLES `x_savingaccounts` WRITE;
/*!40000 ALTER TABLE `x_savingaccounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_savingaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_savingpostings`
--

DROP TABLE IF EXISTS `x_savingpostings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_savingpostings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `savingproduct_id` int(10) unsigned NOT NULL,
  `transaction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `debit_account` int(11) NOT NULL,
  `credit_account` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `savingpostings_savingproduct_id_foreign` (`savingproduct_id`),
  CONSTRAINT `savingpostings_savingproduct_id_foreign` FOREIGN KEY (`savingproduct_id`) REFERENCES `x_savingproducts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_savingpostings`
--

LOCK TABLES `x_savingpostings` WRITE;
/*!40000 ALTER TABLE `x_savingpostings` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_savingpostings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_savingproducts`
--

DROP TABLE IF EXISTS `x_savingproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_savingproducts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `opening_balance` float(10,0) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_savingproducts`
--

LOCK TABLES `x_savingproducts` WRITE;
/*!40000 ALTER TABLE `x_savingproducts` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_savingproducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_savingtransactions`
--

DROP TABLE IF EXISTS `x_savingtransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_savingtransactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `savingaccount_id` int(10) unsigned NOT NULL,
  `amount` float(12,2) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transacted_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_via` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `void` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `savingtransactions_savingaccount_id_foreign` (`savingaccount_id`),
  CONSTRAINT `savingtransactions_savingaccount_id_foreign` FOREIGN KEY (`savingaccount_id`) REFERENCES `x_savingaccounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_savingtransactions`
--

LOCK TABLES `x_savingtransactions` WRITE;
/*!40000 ALTER TABLE `x_savingtransactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_savingtransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_shareaccounts`
--

DROP TABLE IF EXISTS `x_shareaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_shareaccounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `account_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `opening_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `shareaccounts_member_id_foreign` (`member_id`),
  CONSTRAINT `shareaccounts_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `x_members` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_shareaccounts`
--

LOCK TABLES `x_shareaccounts` WRITE;
/*!40000 ALTER TABLE `x_shareaccounts` DISABLE KEYS */;
INSERT INTO `x_shareaccounts` VALUES (1,1,'SH-BS.1','2016-08-29','2016-08-29 07:07:04','2016-08-29 07:07:04');
/*!40000 ALTER TABLE `x_shareaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_shares`
--

DROP TABLE IF EXISTS `x_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `value` float(10,0) NOT NULL DEFAULT '0',
  `transfer_charge` float(10,0) NOT NULL DEFAULT '0',
  `charged_on` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'donor',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_shares`
--

LOCK TABLES `x_shares` WRITE;
/*!40000 ALTER TABLE `x_shares` DISABLE KEYS */;
INSERT INTO `x_shares` VALUES (1,0,0,'donor','2016-08-29 07:03:51','2016-08-29 07:03:51');
/*!40000 ALTER TABLE `x_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_sharetransactions`
--

DROP TABLE IF EXISTS `x_sharetransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_sharetransactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `shareaccount_id` int(10) unsigned NOT NULL,
  `trans_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` float(10,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `sharetransactions_shareaccount_id_foreign` (`shareaccount_id`),
  CONSTRAINT `sharetransactions_shareaccount_id_foreign` FOREIGN KEY (`shareaccount_id`) REFERENCES `x_shareaccounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_sharetransactions`
--

LOCK TABLES `x_sharetransactions` WRITE;
/*!40000 ALTER TABLE `x_sharetransactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_sharetransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_user_role`
--

DROP TABLE IF EXISTS `x_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_user_role` (
  `id` int(11) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `x_user_role_fk1` (`role_id`),
  CONSTRAINT `user_role_fk1` FOREIGN KEY (`role_id`) REFERENCES `x_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_role_fk` FOREIGN KEY (`user_id`) REFERENCES `x_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_user_role`
--

LOCK TABLES `x_user_role` WRITE;
/*!40000 ALTER TABLE `x_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_users`
--

DROP TABLE IF EXISTS `x_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT NULL,
  `branch_id` int(10) unsigned DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `users_fk` FOREIGN KEY (`branch_id`) REFERENCES `x_branches` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_users`
--

LOCK TABLES `x_users` WRITE;
/*!40000 ALTER TABLE `x_users` DISABLE KEYS */;
INSERT INTO `x_users` VALUES (1,'developer','developer@gmail.com','$2y$10$RmWaoqAdU14FZ9KDuPzxUuq2ge0BvsXJ7Gro0QRO0uK6xHEPhNoHm','e7d1e8fd95ed3a5aaa8d4ee9f50456db','NJKhtQt65w3uM5i6HROCmiykYVlEsIjMqtDwqvLlPONoyORg1ncPIDMyClkS',1,'2016-08-29 07:05:01','2016-08-29 08:44:21','admin',NULL,NULL,NULL),(2,'official','officials@gmail.com','$2y$10$PT4qp03rzBoKb0H8SI.IsONXHZgrNAvJcpPW0lfh9DdvSavaQXo12','c55a86da0cc1f5ecae8e94ab60e795f2',NULL,1,'2016-08-29 08:43:56','2016-08-29 08:43:56','admin',NULL,NULL,NULL);
/*!40000 ALTER TABLE `x_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_vehicleexpenses`
--

DROP TABLE IF EXISTS `x_vehicleexpenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_vehicleexpenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `asset_account_id` int(10) unsigned NOT NULL,
  `expense_account_id` int(10) unsigned NOT NULL,
  `amount` float(15,2) NOT NULL,
  `date` date NOT NULL,
  `expenseincurred` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `vehicleexpenses_vehicle_id_index` (`vehicle_id`),
  KEY `vehicleexpenses_member_id_index` (`member_id`),
  KEY `vehicleexpenses_asset_account_id_index` (`asset_account_id`),
  KEY `vehicleexpenses_expense_account_id_index` (`expense_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_vehicleexpenses`
--

LOCK TABLES `x_vehicleexpenses` WRITE;
/*!40000 ALTER TABLE `x_vehicleexpenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_vehicleexpenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_vehicleincomes`
--

DROP TABLE IF EXISTS `x_vehicleincomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_vehicleincomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `asset_account_id` int(10) unsigned NOT NULL,
  `income_account_id` int(10) unsigned NOT NULL,
  `equity_account_id` int(10) unsigned NOT NULL,
  `equity_credit_journal_id` int(10) unsigned NOT NULL,
  `equity_debit_journal_id` int(10) unsigned NOT NULL,
  `savingtransaction_id` int(10) unsigned DEFAULT NULL,
  `sharetransaction_id` int(10) unsigned DEFAULT NULL,
  `savings_credit_journal_id` int(10) unsigned DEFAULT NULL,
  `savings_debit_journal_id` int(10) unsigned DEFAULT NULL,
  `asset_journal_id` int(10) unsigned DEFAULT NULL,
  `interest_credit_journal_id` int(10) unsigned DEFAULT NULL,
  `interest_debit_journal_id` int(10) unsigned DEFAULT NULL,
  `principal_credit_journal_id` int(10) unsigned DEFAULT NULL,
  `principal_debit_journal_id` int(10) unsigned DEFAULT NULL,
  `loanrepayment_principal_id` int(10) unsigned DEFAULT NULL,
  `loanrepayment_interest_id` int(10) unsigned DEFAULT NULL,
  `income_journal_id` int(10) unsigned DEFAULT NULL,
  `loanaccount_id` int(10) unsigned DEFAULT NULL,
  `loantransaction_id` int(10) unsigned DEFAULT NULL,
  `amount` float(15,2) NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `vehicleincomes_vehicle_id_index` (`vehicle_id`),
  KEY `vehicleincomes_member_id_index` (`member_id`),
  KEY `vehicleincomes_asset_account_id_index` (`asset_account_id`),
  KEY `vehicleincomes_income_account_id_index` (`income_account_id`),
  KEY `vehicleincomes_equity_account_id_index` (`equity_account_id`),
  KEY `vehicleincomes_equity_credit_journal_id_index` (`equity_credit_journal_id`),
  KEY `vehicleincomes_equity_debit_journal_id_index` (`equity_debit_journal_id`),
  KEY `vehicleincomes_savingtransaction_id_index` (`savingtransaction_id`),
  KEY `vehicleincomes_sharetransaction_id_index` (`sharetransaction_id`),
  KEY `vehicleincomes_savings_credit_journal_id_index` (`savings_credit_journal_id`),
  KEY `vehicleincomes_savings_debit_journal_id_index` (`savings_debit_journal_id`),
  KEY `vehicleincomes_asset_journal_id_index` (`asset_journal_id`),
  KEY `vehicleincomes_interest_credit_journal_id_index` (`interest_credit_journal_id`),
  KEY `vehicleincomes_interest_debit_journal_id_index` (`interest_debit_journal_id`),
  KEY `vehicleincomes_principal_credit_journal_id_index` (`principal_credit_journal_id`),
  KEY `vehicleincomes_principal_debit_journal_id_index` (`principal_debit_journal_id`),
  KEY `vehicleincomes_loanrepayment_principal_id_index` (`loanrepayment_principal_id`),
  KEY `vehicleincomes_loanrepayment_interest_id_index` (`loanrepayment_interest_id`),
  KEY `vehicleincomes_income_journal_id_index` (`income_journal_id`),
  KEY `vehicleincomes_loanaccount_id_index` (`loanaccount_id`),
  KEY `vehicleincomes_loantransaction_id_index` (`loantransaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_vehicleincomes`
--

LOCK TABLES `x_vehicleincomes` WRITE;
/*!40000 ALTER TABLE `x_vehicleincomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_vehicleincomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_vehicles`
--

DROP TABLE IF EXISTS `x_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `make` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `regno` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_vehicles`
--

LOCK TABLES `x_vehicles` WRITE;
/*!40000 ALTER TABLE `x_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_vendors`
--

DROP TABLE IF EXISTS `x_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_vendors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_vendors`
--

LOCK TABLES `x_vendors` WRITE;
/*!40000 ALTER TABLE `x_vendors` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_vendors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-29 16:33:44
